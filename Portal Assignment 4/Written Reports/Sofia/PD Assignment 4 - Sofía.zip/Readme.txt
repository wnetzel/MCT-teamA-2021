GRANULAR SYNTH

Together with this Readme file, I'm submitting the patch pd file
named 'Assignment 4', the pd abstraction 'grainAbst' and a folder
of 4 sample sounds inside.

Gui: 
- For selecting a file, the user has the choice to select a file
from their computer or select one of the sample files I included.
- Underneath the buttons for selecting files, the user can see the
total size in samples of the selected file so that they can 
choose an appropriate start time considering.
- The Array receives the data of the chosen files.

- The start number object lets the user select the start time
for the file.
- The bang to the left lets the sound keep sounding forever or
not.
- The slider for the master volume is pretty self-explanatory.
- The slider for the grain duration and speed also show in a
number object what the user selects.

All of the gui objects send through the send and receive settings
so as to be able to transfer the data to the subpatches without
any 'cables'. This way, we achieve a more aesthetic interface.


Subpatches:
- In the Select Sound subpatch, we find that the Vradio sends into
it and routes the info so as to either empty the array or select
the sounds from the appropriate folder. Also, the bang for selecting
files sends into this subpatch so as to open the panel for selecting
the computer files. Both methods end in the soundfiler after
resizing the Array. The number object used as visible output of
the soundfiler is sending that number to other parts of the patch.

- In the Inner Workings subpatch, we find the main body of the
granular synth. The start point in the Gui is sent in here and
connects to the clone of the grains and to the dac. Befor that,
I added a phasor that translates the signal into numbers with the
snapshot triggered by a metro 100. When the bang in the Gui is
clicked, the toggle is activated and the grain will keep sounding
until desactivated. That allows you to play a bit with the duration
and speed.

- In the Key Controls subpatch, it's exactly what you expect.
The key object connected with select object to tell each of the
things in the Gui (except for the start time and the array) what
key activates them. For the sliders, a intertwined + and i object
where needed so that the values 1 and -1 kept adding onto each
other.

- Finally, I added a subpatch with the contents of the grain abstract
just in case.



- I tried to add a recording function, but didn't manage to.